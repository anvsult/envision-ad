package com.envisionad.webservice.reservation.dataaccesslayer;

import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ReservationRepository extends JpaRepository<Reservation, Integer> {

        @Query("""
                            SELECT (COUNT(r) > 0)
                            FROM Reservation r
                            WHERE r.mediaId = :mediaId
                              AND r.campaignId = :campaignId
                              AND r.status IN ('CONFIRMED', 'PENDING')
                        """)
        boolean existsConfirmedReservationForMediaAndCampaign(
                        @Param("mediaId") UUID mediaId,
                        @Param("campaignId") String campaignId);

        List<Reservation> findAllReservationsByMediaId(UUID mediaId);

        @Query("SELECT r FROM Reservation r WHERE r.mediaId = :mediaId " +
                        "AND r.status = 'CONFIRMED' " +
                        "AND r.startDate < :endDate " +
                        "AND r.endDate > :startDate")
        List<Reservation> findAllActiveReservationsByMediaIdAndDateRange(
                        @Param("mediaId") UUID mediaId,
                        @Param("startDate") @NotNull LocalDateTime startDate,
                        @Param("endDate") @NotNull LocalDateTime endDate);

        Optional<Reservation> findByReservationId(String reservationId);

        @Query("SELECT COUNT(DISTINCT r.campaignId) FROM Reservation r WHERE r.advertiserId = :advertiserId " +
                        "AND r.status = 'CONFIRMED' " +
                        "AND r.startDate <= :now " +
                        "AND r.endDate >= :now")
        int countActiveCampaignsByAdvertiserId(@Param("advertiserId") String advertiserId,
                        @Param("now") LocalDateTime now);

        @Query("SELECT r FROM Reservation r WHERE r.advertiserId = :advertiserId " +
                        "AND r.status = 'CONFIRMED' " +
                        "AND r.startDate < :endDate " +
                        "AND r.endDate > :startDate")
        List<Reservation> findConfirmedReservationsByAdvertiserIdAndDateRange(
                        @Param("advertiserId") String advertiserId,
                        @Param("startDate") LocalDateTime startDate,
                        @Param("endDate") LocalDateTime endDate);

        @Query("""
                        SELECT (COUNT(r) > 0)
                        FROM Reservation r
                        WHERE r.campaignId = :campaignId
                          AND r.status = :status
                          AND r.endDate >= :now
                """)
        boolean existsByCampaignIdAndStatus(
                @Param("campaignId") String campaignId,
                @Param("status") ReservationStatus status,
                @Param("now") LocalDateTime now
        );
}
